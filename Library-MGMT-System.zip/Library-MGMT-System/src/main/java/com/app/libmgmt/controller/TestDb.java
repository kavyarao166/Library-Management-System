package com.app.libmgmt.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestDb
 */
@WebServlet("/TestDb")
public class TestDb extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username="KavyaRao";
		String pass="root";
		
		String jdbcUrl="jdbc:mysql://localhost:3306/user?useSSL=false";
		String driver="com.mysql.cj.Driver";
		
		try {
			
			
			PrintWriter out=response.getWriter();
			out.println("connection established"+jdbcUrl);
			Class.forName(driver);
			
			Connection myCon=DriverManager.getConnection(jdbcUrl,username,pass);
			
			out.println("Connection successful...");
			myCon.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
