package com.app.libmgmt.controller;

import java.sql.Connection;
import java.sql.DriverManager;

public class TestJdbc {

	public static void main(String[] args) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		String jdbcUrl="jdbc:mysql://127.0.0.1:3306/student_tracker?useSSL=false";
		String user="root";
		String pass="root";
		
		try {
			System.out.println("Connecting to database: " +jdbcUrl);
			
			Connection myconn= DriverManager.getConnection(jdbcUrl,user,pass);
			
			System.out.println("Connection successful!!!");
		}
		catch(Exception e) {
			e.printStackTrace();
		}

}
}
