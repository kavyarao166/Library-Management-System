package com.app.libmgmt.dao;

import java.sql.SQLException;
import java.util.List;

import com.app.libmgmt.model.User;

public interface UserDao {

	public int id(User user) throws SQLException;

	public int updateUser(User user) throws SQLException;

	public int deleteUser(User user) throws SQLException;

	public User getUserById(int id) throws SQLException;

	public List<User> getUserByName(String name) throws SQLException;

	public List<User> getUserByExpiryDate(String expirtDate) throws SQLException;

	public List<User> getAllUsers() throws SQLException;
}
