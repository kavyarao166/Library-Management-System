package com.app.libmgmt.dao;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.libmgmt.model.User;

@Repository
public class UserDaoImpl implements UserDao {
	
	@Autowired
	private SessionFactory sessionFactory;

	public int id(User user) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	public int updateUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deleteUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	public User getUserById(int id) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	public List<User> getUserByName(String name) throws SQLException {

		return null;
	}

	public List<User> getUserByExpiryDate(String expirtDate) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	public List<User> getAllUsers() throws SQLException {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from User",User.class);
		List<User> user=query.getResultList();
		
		return user;
	}

}
